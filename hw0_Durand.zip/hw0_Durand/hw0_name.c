/*
Taylor Durand
This program will print my name
*/

#include <stdio.h>

int main()
{
    printf("Taylor Durand\n"); // the \n  is here for VSCode output to get through the buffer

    return 0;
}
/*
Taylor Durand
This program will print CSE1310-004
*/
#include <stdio.h>

int main()
{
    printf("CSE1310-004\n"); // "\n" was applied for VSC Buffer

    return 0;
}
/*
Durand, Taylor
This program will print CSE in large text
*/

#include <stdio.h>

int main()
{
    printf("----   ----  ----\n");
    printf("|  |   |  | |\n");
    printf("|      |    |\n");
    printf("|       \\   ----\n");
    printf("|        |  |\n");
    printf("|  |  |  |  |\n");
    printf("----  ----   ----\n");
    
    return 0;
}